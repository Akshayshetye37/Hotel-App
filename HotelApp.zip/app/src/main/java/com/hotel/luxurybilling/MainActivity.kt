package com.hotel.luxurybilling

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LuxuryHotelTheme {
                MainScreen()
            }
        }
    }
}

@Composable
fun LuxuryHotelTheme(content: @Composable () -> Unit) {
    val gold = Color(0xFFD4AF37)
    val darkBg = Color(0xFF121212)
    val surface = Color(0xFF1E1E1E)
    
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = gold,
            background = darkBg,
            surface = surface,
            onPrimary = Color.Black,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen() {
    val context = LocalContext.current
    val sharedPreferences = context.getSharedPreferences("HotelPrefs", Context.MODE_PRIVATE)
    
    // Load saved details, defaulting to your homestay
    var hotelName by remember { 
        mutableStateOf(sharedPreferences.getString("HOTEL_NAME", "Hari Om Retreat - Homestay (हरी ओम रिट्रीट)") ?: "Hari Om Retreat - Homestay (हरी ओम रिट्रीट)") 
    }
    var hotelAddress by remember { 
        mutableStateOf(sharedPreferences.getString("HOTEL_ADDRESS", "Aravi, Shrivardhan, Maharashtra") ?: "Aravi, Shrivardhan, Maharashtra") 
    }
    var hotelContact by remember { 
        mutableStateOf(sharedPreferences.getString("HOTEL_CONTACT", "") ?: "") 
    }
    
    var selectedTab by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(hotelName, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Text("📊") },
                    label = { Text("Dashboard") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Text("🧾") },
                    label = { Text("Billing") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Text("⚙️") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding).fillMaxSize()) {
            when (selectedTab) {
                0 -> DashboardScreen()
                1 -> BillingScreen()
                2 -> SettingsScreen(
                    currentName = hotelName,
                    currentAddress = hotelAddress,
                    currentContact = hotelContact
                ) { newName, newAddress, newContact ->
                    hotelName = newName
                    hotelAddress = newAddress
                    hotelContact = newContact
                    
                    // Save all details permanently to the device
                    sharedPreferences.edit()
                        .putString("HOTEL_NAME", newName)
                        .putString("HOTEL_ADDRESS", newAddress)
                        .putString("HOTEL_CONTACT", newContact)
                        .apply()
                }
            }
        }
    }
}

@Composable
fun DashboardScreen() {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Overview", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(16.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            StatCard("Available Rooms", "8", Modifier.weight(1f))
            Spacer(modifier = Modifier.width(16.dp))
            StatCard("Today's Revenue", "₹0", Modifier.weight(1f))
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier.height(120.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, fontSize = 13.sp, color = Color.Gray)
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillingScreen() {
    var guestName by remember { mutableStateOf("") }
    var roomNumber by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Generate Invoice", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = guestName,
            onValueChange = { guestName = it },
            label = { Text("Guest Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = roomNumber,
            onValueChange = { roomNumber = it },
            label = { Text("Room Number") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedTextField(
            value = amount,
            onValueChange = { amount = it },
            label = { Text("Total Amount (₹)") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { /* PDF Generation Logic */ },
            modifier = Modifier.fillMaxWidth().height(55.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.Black)
        ) {
            Text("Create Bill", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    currentName: String, 
    currentAddress: String, 
    currentContact: String, 
    onSave: (String, String, String) -> Unit
) {
    var tempName by remember { mutableStateOf(currentName) }
    var tempAddress by remember { mutableStateOf(currentAddress) }
    var tempContact by remember { mutableStateOf(currentContact) }

    Column(modifier = Modifier.padding(16.dp)) {
        Text("Business Details", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = tempName,
            onValueChange = { tempName = it },
            label = { Text("Hotel Name") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))
        
        OutlinedTextField(
            value = tempAddress,
            onValueChange = { tempAddress = it },
            label = { Text("Address") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(8.dp))
        
        OutlinedTextField(
            value = tempContact,
            onValueChange = { tempContact = it },
            label = { Text("Contact Number") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(modifier = Modifier.height(24.dp))
        
        Button(
            onClick = { onSave(tempName, tempAddress, tempContact) },
            modifier = Modifier.fillMaxWidth().height(55.dp),
            shape = RoundedCornerShape(8.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = Color.Black)
        ) {
            Text("Save Details", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}
